public class Q1a
{
  public static void main (String [] args)
  {
    int i=24,n=-6;
    while(i>=n)
    {
      if(i>n)
      {
      System.out.println(i+",");
      }
      else
      {
      System.out.println(i);
      }
      i=i-6;
    }
  }
}