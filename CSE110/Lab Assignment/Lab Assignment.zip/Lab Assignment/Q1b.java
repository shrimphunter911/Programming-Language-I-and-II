public class Q1b
{
  public static void main (String [] args)
  {
    int i=-10,n=20;
    while(i<=n)
    {
      if(i<n)
      {
      System.out.println(i+",");
      }
      else
      {
      System.out.println(i);
      }
      i=i+5;
    }
  }
}